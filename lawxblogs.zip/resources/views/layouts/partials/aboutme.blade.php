<li id="inhype-text-6" class="widget widget_inhype_text">
    <div class="inhype-textwidget-wrapper ">
        <div class="inhype-textwidget"
             data-style="background-color: #f7f7f7;padding: 50px 40px 50px 40px;"
             style="background-color: #f7f7f7;padding: 50px 40px 50px 40px;">
            <h5>Rəfiqə Məlikova<img
                        src="../../../../wp-content/uploads/2019/11/Author-small.png"
                        style="float:right;width: 50px;height:50px;margin-left:30px;" alt=""></h5>
            <p>
                2020-ci ildə Azərbaycan Respublikası Prezidenti yanında Dövlət İdarəçilik Akademiyasının Hüquqşünaslıq ixtisasını bitirmişdir. Təhsil müddətində bir sıra hüquq şirkətlərində təcrübə keçmiş, hüquqi araşdırmalar edərək məqalələr yazmışdır.
            </p>
            <p>14 İyul 2020-ci ildə LawX bloqunu yaratmışdır.</p>
        <a class="btn" href="{{ route('contact') }}"
                                 target="_self">Bizimlə Əlaqə</a>
        </div>
    </div>
</li>
