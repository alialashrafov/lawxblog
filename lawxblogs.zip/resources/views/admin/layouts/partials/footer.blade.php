<!-- build:js /assets/js/core.min.js -->
<script src="/libs/bower/jquery/dist/jquery.js"></script>
<script src="/libs/bower/jquery-ui/jquery-ui.min.js"></script>
<script src="/libs/bower/jQuery-Storage-API/jquery.storageapi.min.js"></script>
<script src="/libs/bower/bootstrap-sass/assets/javascripts/bootstrap.js"></script>
<script src="/libs/bower/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="/libs/bower/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
<script src="/libs/bower/PACE/pace.min.js"></script>
<!-- endbuild -->

<!-- build:js /assets/js/app.min.js -->
<script src="/assets/js/library.js"></script>
<script src="/assets/js/plugins.js"></script>
<script src="/assets/js/app.js"></script>
<!-- endbuild -->
<script src="/libs/bower/moment/moment.js"></script>
<script src="/libs/bower/fullcalendar/dist/fullcalendar.min.js"></script>
<script src="/assets/js/fullcalendar.js"></script>
<script src="/libs/bower/switchery/dist/switchery.js"></script>