<!-- navbar header -->
<div class="navbar-header">
    <button type="button" id="menubar-toggle-btn" class="navbar-toggle visible-xs-inline-block navbar-toggle-left hamburger hamburger--collapse js-hamburger">
        <span class="sr-only">Toggle navigation</span>
        <span class="hamburger-box"><span class="hamburger-inner"></span></span>
    </button>

    <button type="button" class="navbar-toggle navbar-toggle-right collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="zmdi zmdi-hc-lg zmdi-more"></span>
    </button>

    <a href="/admin" class="navbar-brand">
        <span class="brand-icon"><i class="fa fa-line-chart" aria-hidden="true"></i></span>
        <span class="brand-name">Lawxblog</span>
    </a>
</div><!-- .navbar-header -->