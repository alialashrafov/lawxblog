@extends('admin.layouts.master')

@section('title', 'LaWXBlog Idarə Etmə Merkezi')

@section('content')

    <style>body{overflow: hidden;}</style>

    <!-- MAIN CONTENT-->

    <div class="main-content">

        <div class="section__content section__content--p30">

            <div class="container-fluid">
                <div class="container">
                    <div class="text-center text-welcome">
                        <h3 class="mb-2">"LaWXBlog" idarə etmə panelinə xoş gəlmisiniz.</h3>
                        <p>İdarə etmə funksiyaları sol tərəfdə yerləşdirilmişdir.</p>
                    </div>
                </div>
            </div>

        </div>

    </div>

    <!-- END MAIN CONTENT-->

@endsection